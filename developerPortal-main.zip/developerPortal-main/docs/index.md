# SFMS - Secure File Management System

## Introduction & Goals

Secure File Managment System (SFMS) for ITMP will act as a proxy between inbound connections from the public network and AGN. It secures the transfer of files between the partners, customers, users and systems.

Benefits:

- Network layer security, Harmful files will be sanitized before they enter the system
- Big saving due to shared licensing cost
- No dependencies on Vendor.
- Reusable solutions for all the applications. 
- Extendable design
