# How to register component of developer portal
## There are two methods for registering a component.
###  1.  Using the sample catlog-info.yaml & doc folder 
-   Create a Git repository if it doesn't already exist and push your code to it.
-   **Your repository must have visibility as public or internal**
-   Copy the catalog-info.yaml from the [https://github.developer.allianz.io/it-master-platform/developerPortal/blob/main/catlog-info.yaml](https://github.developer.allianz.io/it-master-platform/developerPortal/blob/main/catlog-info.yaml) to the root folder of your repository.
-   Update your catlog-info.yaml file's section with comments, providing details specific to your component.
-   Copy the doc folder from the specified location and place it at the root of your repository.
-   Customize the doc/index.md file according to your component documentation.
-   Goto https://developer.portal.allianz/home 
-   Click "Create" -> "Register Existing Component".
-   Provide the URL of your catalog-info.yaml
-   Analyze and import.
-   Alternatively, You can also refere the steps mentioned here https://cmp.allianz.net/display/BAB/How+to+-+Register+an+API+when+you+have+defined+Developer+Portal+metadata

### 2.  Register API using Developer Portal Template

- Follow the steps described here https://cmp.allianz.net/display/BAB/How+to+-+Register+an+API+and+create+mandatory+metadata)
- When prompted, please provide value of "custome information" as "ideathon2024,indiaHub". you can provide additional values after comma. make sure this value is in lower case and contains onyl a-z or 0-9. This value will become the TAG of your component. 

## Troubleshooting

 - Ensure that the visibility of your Git repository is set to either public or internal.
 - Ensure that your component hasn't been registered previously. If registration has failed or it already exists, follow these steps to remove it:
	 - Search and select the component, or navigate to the catalog and  search for the tag specific to your component.
	 - Click on the  component.
	 - On the component page, click on the icon with three  vertical dots in the top right corner. 
	 - Select the "Unregister  Entity" option.
